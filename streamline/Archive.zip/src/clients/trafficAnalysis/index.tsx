
const TrafficAnalysisClient = ({organization}: {organization: {label:string, value:string}|null}) => {
  console.log('organization', organization);
  return (
    <div>TrafficAnalysisClient</div>
  )
}

export default TrafficAnalysisClient