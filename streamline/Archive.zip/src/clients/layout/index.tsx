"use client";

import { useMemo, useState } from "react";

import Navbar, {
  NavItem,
} from "@/src/components/navbaar";

import Performance from "../performance";
import TrafficAnalysisClient from "../trafficAnalysis";
import UTPerformance from "../utPerformance";
import { FormProvider, useForm, useWatch } from "react-hook-form";
import { CommonSelect } from "@/src/components/commonSelect";
import Image from "next/image";
import { Images } from "@/src/images";

const ClientHome = () => {
  const [activeTab, setActiveTab] = useState(
    "eline-performance"
  );

  const navLinks: NavItem[] = useMemo(()=>[
    {
      label: "E-Line Performance Metrics",
      key: "eline-performance",
      subTitle:'ext.pathway.eline.perf'
    },
    {
      label: "E-Line Traffic Analysis",
      key: "eline-traffic",
       subTitle:'ext.pathway.eline.traffic',
    },
    {
      label: "UT Performance Metrics",
      key: "ut-performance",
       subTitle:'ext.pathway.ut.perf'
    },
  ],[]);

  const formMethods = useForm({
    defaultValues:{
      organization:null
    }
  })

  const {control} = formMethods

  const orgnaizationSelected = useWatch({
    control,
    name:'organization'
  });

  const selectedModule = useMemo(()=>{
    return navLinks.find((item)=>item.key===activeTab)
  },[activeTab,navLinks])

  return (
    <section>
      <Navbar
        logo="Streaming Management"
        links={navLinks}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />
      <FormProvider {...formMethods}>
       <form className="px-5 w-full md:w-2/4 flex items-center justify-center my-10">
        <CommonSelect
        label="Organization" 
        control={control} 
        name="organization" 
        placeholder="Select Organization" 
        options={[
          {label:"Pathway Portal Synthetic Organization NCBCC-1", value:"36ef3d8a-400e-4c46-b1b7-2729162b47c4"},
          {label:"Pathway Portal Synthetic Organization NCBCC-2", value:"c3d4e5f6-90d4-44ab-8d8c-3191266300fa"},
          {label:"Pathway Portal Synthetic Organization NCBCC-4-1-1", value:"b8c9d0e1-1528-435e-b5af-5f67d8b64d3f"},
        ]}/>
        </form> 
      </FormProvider>
      {selectedModule?.subTitle&&<span className="h-5 flex items-center px-5 w-full text-black text-normal md:text-lg font-semibold">Topic Name : <span className="font-normal mx-2">{selectedModule?.subTitle}</span></span>}

      {!orgnaizationSelected&&<div className="flex flex-col items-center justify-center w-full h-[60vh]">
        <Image src={Images.noData} alt="No Data"/>
        <label className="text-sm md:text-lg">Please select an organization to view the metrics</label>
        </div>}

      <div className="p-6">
        {activeTab === "eline-performance" && orgnaizationSelected && (
          <Performance organization={orgnaizationSelected}/>
        )}

        {activeTab === "eline-traffic" && orgnaizationSelected &&  (
          <TrafficAnalysisClient organization={orgnaizationSelected}/>
        )}

        {activeTab === "ut-performance" && orgnaizationSelected &&  (
          <div><UTPerformance organization={orgnaizationSelected}/></div>
        )}
      </div>
    </section>
  );
};

export default ClientHome;