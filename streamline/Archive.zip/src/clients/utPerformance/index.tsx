
const UTPerformance = ({organization}: {organization: {label:string, value:string}|null}) => {
    console.log('organization', organization);
  return (
    <div>UTPerformance</div>
  )
}

export default UTPerformance