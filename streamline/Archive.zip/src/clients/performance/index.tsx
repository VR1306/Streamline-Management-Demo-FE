
const Performance = ({organization}: {organization: {label:string, value:string}|null}) => {
  console.log('organization', organization);
  return (
    <div>Performance Metrics for the Organization: {organization?.label}</div>
  )
}

export default Performance